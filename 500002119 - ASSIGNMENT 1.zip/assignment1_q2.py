import math
while True:
    num = float(input("Enter a number greater than 2: "))
    if num> 2:
        break
    else:
        print("Please enter a number greater than 2.")
count = 0
while num >= 2:
    num = math.sqrt(num)
    count += 1
    print(f"{count}: {num:.3f}")
