while True:
    usernum = int(input("Enter a non-negative integer: "))
    if usernum >= 0:
        break
    else:
        print("A non-negative number is required.")
factorial = 1
current = 1
while current <= usernum:
    factorial *= current
    current += 1

# Print the result
print(f"The factorial of {usernum} is {factorial}")

