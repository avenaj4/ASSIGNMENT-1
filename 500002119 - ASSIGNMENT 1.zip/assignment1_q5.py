def calculate_letter_grade(average_score):
    if 80 < average_score <= 100:
        return 'A'
    elif 60 < average_score <= 80:
        return 'B'
    elif 49 <= average_score <= 60:
        return 'C'
    else:
        return 'F'

grade_size = int(input("How many students are in the class? "))

for i in range(1, grade_size + 1):
    stu_name = input(f"\nWhat is the name of student {i}? ")
    score1 = float(input(f"Enter {stu_name}'s first score: "))
    score2 = float(input(f"Enter {stu_name}'s second score: "))
    average_score = (score1 + score2) / 2
    letter_grade = calculate_letter_grade(average_score)
    print(f"\n{stu_name} has an average score of {average_score:.2f}, which earns them a grade of {letter_grade}!")
