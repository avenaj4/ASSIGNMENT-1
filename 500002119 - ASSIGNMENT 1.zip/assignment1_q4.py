x, y = map(float, input("Enter a point with two coordinates (x, y): ").split(','))

half_width = 10 / 2  
half_height = 5 / 2  

if abs(x) <= half_width and abs(y) <= half_height:
    print(f"Point ({x}, {y}) is in the rectangle")
else:
    print(f"Point ({x}, {y}) is not in the rectangle")

