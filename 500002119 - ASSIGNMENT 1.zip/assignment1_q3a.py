usernum = int(input("Enter a non-negative integer: "))
factorial = 1
current = 1
while current <= usernum:
    factorial *= current
    current += 1
print(f"The factorial of {usernum} is {factorial}")

