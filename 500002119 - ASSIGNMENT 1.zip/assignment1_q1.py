import math
def calculate_plants(area, spacing):
    return int(area / (spacing ** 2))
def calculate_soil_volume(area, depth):
    return round((area * depth) / 27, 1)  
def calculate_fill_volume(total_area, flowerbed_area, depth):
    fill_area = total_area - flowerbed_area
    return round((fill_area * depth) / 27, 1)

side_length = float(input("Enter the length of one side of the garden (in feet): "))
spacing = float(input("Enter the spacing between plants (in feet): "))
soil_depth = float(input("Enter the depth of the garden soil (in feet): "))
fill_depth = float(input("Enter the depth of the fill material (in feet): "))

total_area = side_length ** 2  
radius = side_length / 4  
circle_area = math.pi * (radius ** 2)
semicircle_area = (math.pi * (radius ** 2)) / 2
totalflowerbed_area = (4 * semicircle_area) + circle_area
plants_per_semicircle = calculate_plants(semicircle_area, spacing)
plants_in_circle = calculate_plants(circle_area, spacing)

total_plants = 4 * plants_per_semicircle + plants_in_circle

10
0.5
0.833
soil_per_semicircle = calculate_soil_volume(semicircle_area, soil_depth)

soil_in_circle = calculate_soil_volume(circle_area, soil_depth)

total_soil = 4 * soil_per_semicircle + soil_in_circle

total_fill = calculate_fill_volume(total_area, totalflowerbed_area, fill_depth)

print(f"\nGarden Requirements:")
print(f"Plants for each semicircle flowerbed: {plants_per_semicircle}")
print(f"Plants for the central circular flowerbed: {plants_in_circle}")
print(f"Total number of plants for the garden: {total_plants}")
print(f"Soil needed for each semicircle: {soil_per_semicircle} cubic yards")
print(f"Soil needed for the central circle: {soil_in_circle} cubic yards")
print(f"Total soil required: {total_soil} cubic yards")
print(f"Total fill material needed: {total_fill} cubic yards")
